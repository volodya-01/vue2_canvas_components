<template>
  <div class="hello">
    <demo1/>
    <demo2 class="demo1box"/>
  </div>
</template>

<script>
import demo1 from './comon/demo1'
import demo2 from './comon/demo2'

export default {
  name: 'HelloWorld',
  components:{
    demo1,
    demo2
  },
  data () {
    return {
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import "@/styles/global.scss";
.hello{
display: flex;
flex-flow: column;
justify-content: center;
align-items: center;
width: vw(1920);
height: vh(1080);
.demo1box{
  margin-top: 60px
}
}
</style>
